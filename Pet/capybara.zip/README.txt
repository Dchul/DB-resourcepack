Thank you for your download!

Discord Server:
https://discord.gg/5Guw2mjXU8

Pack Installation: 
Just drag and drop everything (except for resourcepack) into your server’s plugins folder!

Model Engine:
1. Write a command /meg reload
2. Grab the resource pack.zip from Model Engine plugin folder.

Install the Resource Pack:
- If you are using ItemsAdder: if there's ItemsAdder folder, they're already provided in there. you are ready to use command /iazip
- If you are using other resourcepack plugin: take the resourcepack from ItemsAdder and put them in your plugin.
- If you don't use any resourcepack plugin: Take the resourcepack folder included in this package. (in this case you can just add these assets to your resourcepack, or just use this resourcepack)

MythicMobs:
1. Make sure to use /mm reload
2. All mobs can be edited through Mate/Mobs/capybara.yml and Mate/Skills/capybara.yml . 
3. The mobs don’t spawn randomly in your worlds by default. If you want that, check git.mythiccraft.io/mythiccraft/MythicMobs/-/wikis/Random-Spawns , or you can ask us in the Discord.

#dcbc723b1bfdb01f66f310fbf0c4d79b