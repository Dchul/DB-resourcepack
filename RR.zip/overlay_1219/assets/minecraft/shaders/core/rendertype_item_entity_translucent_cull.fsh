#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:customglint.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightOnly;
in vec4 tintColor;
in vec2 texCoord0;
in float time;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);

    if (texColor.a < 0.1) {
        discard;
    }

    float t = time * 1000.0;
    vec4 color;

    if (isColorGlint(tintColor)) {
        color = texColor * lightOnly * ColorModulator;
        vec3 glintLayer = computeColorGlint(tintColor.rgb, texCoord0, t);
        color.rgb += glintLayer;
    } else {
        color = texColor * vertexColor * ColorModulator;
    }

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
