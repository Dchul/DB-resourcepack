#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightOnly;
out vec4 tintColor;
out vec2 texCoord0;
out float time;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    tintColor = Color;
    vec4 lightmap = texelFetch(Sampler2, UV2 / 16, 0);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * lightmap;
    lightOnly = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, vec4(1.0)) * lightmap;

    texCoord0 = UV0;
    time = GameTime;
}
