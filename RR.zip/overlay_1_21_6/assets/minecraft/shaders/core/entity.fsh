#version 150

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:bust_vars.glsl>

uniform sampler2D Sampler0;

#moj_import <minecraft:bust.glsl>
#moj_import <minecraft:cameo.glsl>

flat in vec3 cameoTint;
in vec2 texCoord0;
in vec2 texCoord1;
in float player;
in vec4 vertexColor;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 lightMapColor;
in vec4 overlayColor;

out vec4 fragColor;

void main() {
    if (cameoTint.x > -1.0) {
        if (cameoTint.x == 2.0) {
            ivec2 truePixel = ivec2(round(texCoord0 * float(BUST_SIZE) - 0.5));
            ivec2 headPixel = ivec2(round(texCoord0 * 8.0 - 0.5));
            fragColor = bustRender(headPixel, truePixel, true);
            if (fragColor.a < 0.1) discard;
            fragColor.a = 1.0;
        } else {
            fragColor = cameoRender(texCoord0, 68.0 / 70.0, cameoTint);
            if (fragColor.a < 0.1) discard;
        }
        return;
    }

    vec2 uv = texCoord0;
    if (texCoord1.y >= 0.25 || player > 0.) {
        uv = texCoord1;
    }
    vec4 color = texture(Sampler0, uv);
    
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif
    color *= vertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
