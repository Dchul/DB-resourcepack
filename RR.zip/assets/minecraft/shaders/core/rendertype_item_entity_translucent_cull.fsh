#version 150

#moj_import <fog.glsl>
#moj_import <customglint.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightOnly;
in vec4 tintColor;
in vec2 texCoord0;
in vec4 normal;
in float time;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);

    if (texColor.a < 0.1) {
        discard;
    }

    float t = time * 1000.0;
    vec4 color;

    if (isColorGlint(tintColor)) {
        // === 색상 기반 커스텀 글린트 ===
        color = texColor * lightOnly * ColorModulator;
        vec3 glintLayer = computeColorGlint(tintColor.rgb, texCoord0, t);
        color.rgb += glintLayer;
    } else {
        // === 일반 모드 ===
        color = texColor * vertexColor * ColorModulator;
    }

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}