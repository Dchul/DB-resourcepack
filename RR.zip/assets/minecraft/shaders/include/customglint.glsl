// CustomGlint - 커스텀 글린트 공용 함수
// #moj_import <customglint.glsl> 로 사용
//
// glints/ 폴더에서 설정된 색상만 글린트로 인식

// 색상 비교 허용 오차
const float COLOR_TOLERANCE = 0.15;

// ============================================================
// 설정된 글린트 색상 (자동 생성됨)
// ============================================================
const int GLINT_COLOR_COUNT = 10;
const vec3 GLINT_COLOR_0 = vec3(0.0000, 1.0000, 0.0000); // green (#00FF00)
const vec3 GLINT_COLOR_1 = vec3(0.5020, 1.0000, 0.0000); // chartreuse (#80FF00)
const vec3 GLINT_COLOR_2 = vec3(0.0000, 1.0000, 0.3765); // aquamarine (#00FF60)
const vec3 GLINT_COLOR_3 = vec3(0.0000, 0.4392, 1.0000); // blue (#0070FF)
const vec3 GLINT_COLOR_4 = vec3(0.4549, 0.0000, 1.0000); // violet (#7400FF)
const vec3 GLINT_COLOR_5 = vec3(0.0000, 1.0000, 0.4863); // spring_green (#00FF7C)
const vec3 GLINT_COLOR_6 = vec3(1.0000, 0.0000, 0.4863); // rose (#FF007C)
const vec3 GLINT_COLOR_7 = vec3(0.1961, 0.8039, 0.1961); // lime (#32CD32)
const vec3 GLINT_COLOR_8 = vec3(1.0000, 0.0000, 0.0000); // red (#FF0000)
const vec3 GLINT_COLOR_9 = vec3(0.1765, 0.4235, 0.4235); // dark_teal (#2D6C6C, 고립 애매색 — 무채색은 black/gray 염료 충돌로 불가)


// ============================================================
// 노이즈 함수
// ============================================================

float glint_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float glint_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float a = glint_hash(i);
    float b = glint_hash(i + vec2(1.0, 0.0));
    float c = glint_hash(i + vec2(0.0, 1.0));
    float d = glint_hash(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// ============================================================
// 색상 비교 유틸리티
// ============================================================

bool colorMatch(vec3 a, vec3 b) {
    return distance(a, b) < COLOR_TOLERANCE;
}

// ============================================================
// 글린트 타입 감지 (색상 매칭)
// ============================================================

bool isColorGlint(vec4 color) {
    if (colorMatch(color.rgb, GLINT_COLOR_0)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_1)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_2)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_3)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_4)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_5)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_6)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_7)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_8)) return true;
    if (colorMatch(color.rgb, GLINT_COLOR_9)) return true;
    return false;
}

int getColorGlintIndex(vec4 color) {
    if (colorMatch(color.rgb, GLINT_COLOR_0)) return 0;
    if (colorMatch(color.rgb, GLINT_COLOR_1)) return 1;
    if (colorMatch(color.rgb, GLINT_COLOR_2)) return 2;
    if (colorMatch(color.rgb, GLINT_COLOR_3)) return 3;
    if (colorMatch(color.rgb, GLINT_COLOR_4)) return 4;
    if (colorMatch(color.rgb, GLINT_COLOR_5)) return 5;
    if (colorMatch(color.rgb, GLINT_COLOR_6)) return 6;
    if (colorMatch(color.rgb, GLINT_COLOR_7)) return 7;
    if (colorMatch(color.rgb, GLINT_COLOR_8)) return 8;
    if (colorMatch(color.rgb, GLINT_COLOR_9)) return 9;
    return -1;
}


// ============================================================
// 프로시저럴 글린트 패턴
// ============================================================

float proceduralGlintPattern(vec2 uv, float time) {
    // 대각선 스트라이프
    float diagonal = uv.x + uv.y;
    float stripe = sin(diagonal * 6.2831853) * 0.5 + 0.5;
    stripe = mix(0.3, 1.0, stripe);

    // 이동하는 노이즈 웨이브
    vec2 waveDir1 = vec2(-1.0, 1.0) * time * 0.3;
    vec2 waveDir2 = vec2(1.0, 0.5) * time * 0.25;

    float n1 = glint_noise(uv * 4.0 + waveDir1);
    float n2 = glint_noise(uv * 6.0 + waveDir2);

    float wave1 = sin((uv.x + uv.y) * 3.0 - time * 1.5) * 0.5 + 0.5;
    float wave2 = sin((uv.x - uv.y) * 4.0 + time * 1.2) * 0.5 + 0.5;

    float n = n1 * wave1 + n2 * wave2;
    n = pow(n, 0.7);
    n = mix(0.1, 1.2, n);

    // 스파클 효과
    float sparkle = glint_noise(uv * 15.0 + vec2(time * 0.8, -time * 0.6));
    sparkle = pow(sparkle, 4.0) * 0.8;

    return stripe * n + sparkle;
}

// ============================================================
// 최종 글린트 색상 계산
// ============================================================

vec3 computeColorGlint(vec3 glintColor, vec2 uv, float time) {
    vec2 glintUV1 = uv * 8.0 + vec2(-time * 0.1, time * 0.1);
    vec2 glintUV2 = uv * 8.0 + vec2(time * 0.08, time * 0.08);

    float glint1 = proceduralGlintPattern(glintUV1, time);
    float glint2 = proceduralGlintPattern(glintUV2, time);
    float glintStrength = glint1 * glint2;

    // dark_teal = "예쁜 검정" 글린트 (리서치: 검정 base + 좁은 specular 광택 = 흑요석 느낌)
    //  · 항상 어두운 base를 깔아 흰빛 포화 차단
    //  · 패턴의 좁은 peak(pow로 좁힘)에서만 '덜 어둡게' 해 광택 줄무늬 → 가장자리 강조 효과
    //  · vec3 균일이라 무채색(보라끼 없음)
    if (colorMatch(glintColor, GLINT_COLOR_9)) {
        // 색조 없는 흑백 글린트 — 검정 바탕 + 흰색 광택만 (vec3 균일 = 무채색)
        //  · dark_teal만 빠른 time으로 패턴 재계산 → 일렁임 속도 ↑ (9색은 공용 속도 유지)
        float ft = time * 2.5;
        float g1 = proceduralGlintPattern(uv * 8.0 + vec2(-ft * 0.1, ft * 0.1), ft);
        float g2 = proceduralGlintPattern(uv * 8.0 + vec2(ft * 0.08, ft * 0.08), ft);
        float s = clamp(g1 * g2, 0.0, 1.0);
        float darken = 0.23 - s * 0.14;     // 검정 농도도 일렁이게
        float bright = pow(s, 2.5) * 0.40;  // 흰 광택
        return vec3(bright - darken);
    }

    return glintColor * glintStrength;
}