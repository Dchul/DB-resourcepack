#version 330
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 61
#define SHADER_VERSION 5
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#endif
in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;void main() {
#ifdef IS_GRAYSCALE
vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
vec4 texColor = texture(Sampler0, texCoord0);
#endif
#ifdef IS_SEE_THROUGH
vec4 color = texColor * vertexColor;
#else
vec4 color = texColor * vertexColor * ColorModulator;
#endif
if (color.a < 0.1) {discard;}
#ifdef IS_SEE_THROUGH
fragColor = color * ColorModulator;
#elif defined(IS_GUI)
fragColor = color;
#else
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}