#version 330

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif
#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif

#moj_import <minecraft:cameo.glsl>

flat out vec3 cameoTint;
out vec2 texCoord0;
out vec2 texCoord1;
out float player;
out vec4 vertexColor;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#ifndef EMISSIVE
out vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

#define STACK_STEP 1024.0
#define STACK_HALF (0.5 * STACK_STEP)

float slimArms() {
    return 1.0 - sign(length(texture(Sampler0, vec2(54.0 / 64.0, 20.0 / 64.0)).rgb));
}

void main() {
    vec3 pos = Position;

#ifdef NO_CARDINAL_LIGHTING
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif
#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif
#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    cameoTint = vec3(-1);
    vec2 modifiedUV = UV0;
    texCoord1 = UV0;
    player = 0.0;
    if (textureSize(Sampler0, 0).x != 64) {
    } else {
        if (ProjMat[2][3] == 0.0 && Position.z < -100.) {
            int quadId = (gl_VertexID / 4) % 24;
            if (quadId >= 6 || round(Normal.z) != -1.) {
                pos = vec3(0);
            } else {
                cameoTint = vec3(2);
                const vec2 uvs[] = vec2[](vec2(1, 0), vec2(0, 0), vec2(0, 1), vec2(1, 1));
                modifiedUV = uvs[gl_VertexID % 4];
                if (quadId == 2 || quadId == 4) {
                    pos.xy = (uvs[(gl_VertexID) % 4] * vec2(1., 70. / 79.) + vec2(0., 1. - 70. / 79.)) * (2. / vec2(ProjMat[0][0], -ProjMat[1][1]));
                    pos = round(pos);
                    pos.x += 1.;  // X 위치 (완벽 베이스). 크기/1칸 시도 원복
                    cameoTint = cameoPickColor();
                }
            }
        }

        int x = -int((Position.y - STACK_HALF) / STACK_STEP);

        if (x != 0) {
            pos.y += STACK_STEP * x;
            x++;
        }
        
        x = x * 2 + (gl_VertexID / 24) % 2; 

        int i = gl_VertexID % 12;
        float slim = slimArms();
        int m0=x%2,m=m0+1;
        if (x == 4 || x == 5) {
            float v = UV0.y/.25;
            if (v<.75)v*=.5;
            float u = UV0.x*2.-m0;
            if (slim == 1.) {
                if (u < 12.0 / 32.0) {
                    u *= 8./7.;
                } else if (u > 20.0 / 32.0 && u < 28.0 / 32.) {
                    u = (i==0||i==3?10.:11.)/14.;
                }
                u *= (14.0 / 64.0);
            } else {
                u *= (16.0 / 64.0);
            }
            modifiedUV = vec2(
                u + (40.0 / 64.0),
                v * (16.0 / 64.0) + m*.25);
        } else if (x == 6 || x == 7) {
            if (x == 6 && UV0.x > 0.5) {
                player = 1.;
            }
            float v = UV0.y/.25;
            if (v<.75)v*=.5;
            float u = UV0.x*2.-m0;
            if (slim == 1.) {
                if (u < 12.0 / 32.0) {
                    u *= 8./7.;
                } else if (u > 20.0 / 32.0 && u < 28.0 / 32.) {
                    u = (i==0||i==3?10.:11.)/14.;
                }
                u *= (14.0 / 64.0);
            } else {
                u *= (16.0 / 64.0);
            }
            modifiedUV = vec2(
                u + ((32.0 + m0*16.) / 64.0),
                v * (16.0 / 64.0) + 48./64.);
        } else if (x == 8 || x == 9) {
            float v0 = UV0.y / (16.0 / 64.0);
            if (v0 < 0.75) {
                v0 *= 0.5;
            }
            float v1 = (x == 8 ? UV0.x : UV0.x - .5) / (32.0 / 64.0);
            if (v1 < 12.0 / 32.0) {
                v1 /= 12./8.;
            } else if (v1 > 20.0 / 32.0 && v1 < 28.0 / 32.) {
                v1 /= 9./8.;
            }
            if (x == 8) {
                modifiedUV = vec2(
                    v1 * (24.0 / 64.0) + (16.0 / 64.0),
                    v0 * (16.0 / 64.0) + (16.0 / 64.0));
            } else {
                modifiedUV = vec2(
                    v1 * (24.0 / 64.0) + (16.0 / 64.0),
                    v0 * (16.0 / 64.0) + (32.0 / 64.0));
            }
        } else if (x == 10 || x == 11) {
            float v0 = UV0.y / (16.0 / 64.0);
            if (v0 < 0.75) {
                v0 *= 0.5;
            }
            if (x == 10) {
                modifiedUV = vec2(
                    UV0.x / (32.0 / 64.0) * (16.0 / 64.0) + (0.0 / 64.0),
                    v0 * (16.0 / 64.0) + (16.0 / 64.0));
            } else {
                modifiedUV = vec2(
                    (UV0.x - 32.0 / 64.0) / (32.0 / 64.0) * (16.0 / 64.0) + (0.0 / 64.0),
                    v0 * (16.0 / 64.0) + (32.0 / 64.0));
            }
        } else if (x == 12 || x == 13) {
            float v0 = UV0.y / (16.0 / 64.0);
            if (v0 < 0.75) {
                v0 *= 0.5;
            }
            if (x == 12) {
                modifiedUV = vec2(
                    UV0.x / (32.0 / 64.0) * (16.0 / 64.0) + (16.0 / 64.0),
                    v0 * (16.0 / 64.0) + (48.0 / 64.0));
            } else {
                modifiedUV = vec2(
                    (UV0.x - 32.0 / 64.0) / (32.0 / 64.0) * (16.0 / 64.0) + (0.0 / 64.0),
                    v0 * (16.0 / 64.0) + (48.0 / 64.0));
            }
        }
    }

    
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);

    texCoord0 = modifiedUV;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(modifiedUV, 0.0, 1.0)).xy;
#endif
}
