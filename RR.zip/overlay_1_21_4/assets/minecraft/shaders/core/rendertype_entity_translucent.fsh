#version 150

#moj_import <minecraft:fog.glsl>

#moj_import <minecraft:bust_vars.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

#moj_import <minecraft:bust.glsl>

#moj_import <minecraft:cameo.glsl>

flat in vec3 cameoTint;
flat in int bustFlag;
flat in int quadId;
in vec2 texCoord0;
in vec2 texCoord1;
in float player;
in vec4 normal;
in vec4 vertexColor;
in float vertexDistance;
in vec4 lightMapColor;
in vec4 overlayColor;

out vec4 fragColor;

void main() {
    if (bustFlag > 0) {
        if (quadId >= 6) discard;
        if (cameoTint.x == -1.0) {
            ivec2 truePixel = ivec2(round(texCoord0 * float(BUST_SIZE) - 0.5));
            ivec2 headPixel = ivec2(round(texCoord0 * 8.0 - 0.5));
            fragColor = bustRender(headPixel, truePixel, bustFlag > 1);
            if (fragColor.a < 0.1) discard;
            fragColor.a = 1.0;
        } else {
            fragColor = cameoRender(texCoord0, 68.0 / 70.0, cameoTint);
            if (fragColor.a < 0.1) discard;
        }
    } else {
        vec2 uv = texCoord0;
        if (texCoord1.y >= 0.25 || player > 0.) {
            uv = texCoord1;
        }
        vec4 color = texture(Sampler0, uv);
        if (color.a < 0.1) {
            discard;
        }
        color *= vertexColor * ColorModulator;
        color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
        color *= lightMapColor;
        fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
    }
}
