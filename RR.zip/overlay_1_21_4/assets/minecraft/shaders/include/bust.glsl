#version 150

float bustSoftMix(float b, float f) {
    return (f < 0.5) ?
        (2.0 * b * f + b * b * (1.0 - 2.0 * f)) :
        (sqrt(b) * (2.0 * f - 1.0) + (2.0 * b * (1.0 - f)));
}

vec3 bustSoftMixEase(vec3 base, vec3 blend, float alpha) {
    return mix(base, vec3(
        bustSoftMix(base.r, blend.r),
        bustSoftMix(base.g, blend.g),
        bustSoftMix(base.b, blend.b)
    ), alpha);
}

vec3 bustHueToRgb(float h) {
    h = fract(h);
    return clamp(vec3(
        abs(h * 6.0 - 3.0) - 1.0,
        2.0 - abs(h * 6.0 - 2.0),
        2.0 - abs(h * 6.0 - 4.0)
    ), 0.0, 1.0);
}

vec3 bustHslToRgb(vec3 hsl) {
    vec3 rgb = bustHueToRgb(hsl.x);
    float chroma = (1.0 - abs(2.0 * hsl.z - 1.0)) * hsl.y;
    return (rgb - 0.5) * chroma + hsl.z;
}

vec4 bustHeadTexel(ivec2 pixel) {
    vec4 fragColor = vec4(0.0);

    fragColor = texelFetch(Sampler0, pixel + ivec2(40, 8), 0);

    if (fragColor.a < 1.0) {
        vec4 tex = texelFetch(Sampler0, pixel + 8, 0);
        if (tex.a > 0.1) {
            fragColor.rgb = mix(tex.rgb, fragColor.rgb, fragColor.a);
            fragColor.a = 1.0;
        }
    }

    if (fragColor.a > 0.1 && fragColor.a < 1.0) {
        fragColor.rgb = mix(vec3(0.0), fragColor.rgb, fragColor.a);
        fragColor.a = 1.0;
    }

    return fragColor;
}

vec3 bustGrade(vec3 col, float h, float s, float l, float alpha) {
    float lo = min(min(col.r, col.g), col.b);
    float hi = max(max(col.r, col.g), col.b);
    float d = hi - lo;
    float sum = hi + lo;
    float kr = (((hi - col.r) / 6.0) + (d / 2.0)) / d;
    float kg = (((hi - col.g) / 6.0) + (d / 2.0)) / d;
    float kb = (((hi - col.b) / 6.0) + (d / 2.0)) / d;
    float hh = 0.0;
    float ss = 0.0;
    float ll = sum / 2.0;
    if (d > 0.0) {
        if (hi == col.r) {
            hh = kb - kg;
        } else if (hi == col.g) {
            hh = (1.0 / 3.0) + kr - kb;
        } else {
            hh = (2.0 / 3.0) + kg - kr;
        }
        hh = fract(hh);
        if (ll < 0.5) {
            ss = d / sum;
        } else {
            ss = d / (2.0 - sum);
        }
    }
    hh = fract(hh + h);
    col = bustHslToRgb(vec3(hh, ss, ll));
    if (d > 0.0) {
        float g = 0.0;
        if (s >= 0.0) {
            if ((s + ss) >= 1.0) {
                g = ss;
            } else {
                g = 1.0 - s;
            }
            g = 1.0 / g - 1.0;
            col = col + (col - ll) * g;
        } else {
            g = s;
            col = ll + (col - ll) * (1.0 + g);
        }
    }
    if (l > 0.0) {
        col = col * (1.0 - l) + l;
    } else if (l < 0.0) {
        col = col + col * l;
    }
    return mix(col, col, alpha);
}

vec4 bustRender(ivec2 headPixel, ivec2 truePixel, bool disabled) {
    vec4 fragColor = bustHeadTexel(headPixel);

    fragColor.rgb = bustGrade(fragColor.rgb,
        BUST_BASE_HUE/100.0,
        BUST_BASE_SAT_ADJ/100.0,
        BUST_BASE_LIGHT_ADJ/100.0,
        BUST_BASE_OPACITY/100.0
    );

    fragColor.rgb = bustSoftMixEase(fragColor.rgb,
        vec3 BUST_OVERLAY_COLOR /255.0,
        BUST_OVERLAY_OPACITY/100.0
    );

    if (truePixel.y == (BUST_SIZE - 1)) {
        fragColor.rgb = bustGrade(fragColor.rgb,
            BUST_SHADOW_HUE/100.0,
            BUST_SHADOW_SAT_ADJ/100.0,
            BUST_SHADOW_LIGHT_ADJ/100.0,
            BUST_SHADOW_OPACITY/100.0
        );
    } else if (truePixel.x == 0 ||
               truePixel.y == 0 ||
               truePixel.x == (BUST_SIZE - 1) ||
               truePixel.y == (BUST_SIZE - 2)) {
        fragColor.rgb = bustSoftMixEase(fragColor.rgb,
            vec3 BUST_OUTLINE_COLOR /255.0,
            BUST_OUTLINE_OPACITY/100.0
        );
    }

    return fragColor;
}
