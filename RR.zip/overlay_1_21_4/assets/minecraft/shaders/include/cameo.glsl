#version 150

struct hitres {
    float t;
    vec3 position;
    vec3 normal;
    vec2 uv;
    vec4 albedo;
};

const float CAMEO_FAR = 1024.0;
const int CAMEO_BANDS = 32;

vec3 cameoShade(vec3 normal, vec3 lightDir) {
    float ndl = max(dot(normal, lightDir), 0.0);
    return sqrt(vec3(mix(0.3, 1.0, ndl)));
}

float cameoSoftMix(float b, float f) {
    return (f < 0.5) ?
        (2.0 * b * f + b * b * (1.0 - 2.0 * f)) :
        (sqrt(b) * (2.0 * f - 1.0) + (2.0 * b * (1.0 - f)));
}

vec3 cameoSoftMixEase(vec3 base, vec3 blend, float alpha) {
    return mix(base, vec3(
        cameoSoftMix(base.r, blend.r),
        cameoSoftMix(base.g, blend.g),
        cameoSoftMix(base.b, blend.b)
    ), alpha);
}

bool slabHit(inout hitres hit, vec3 rayOrig, vec3 direction, vec3 position, vec3 size) {
    vec3 invDir = 1.0 / direction;
    vec3 ext = abs(invDir) * size;
    vec3 tMin = -invDir * (rayOrig - position) - ext;
    vec3 tMax = tMin + ext * 2.0;
    float near = max(max(tMin.x, tMin.y), tMin.z);
    float far = min(min(tMax.x, tMax.y), tMax.z);
    if (near > far || far < 0.0 || near > hit.t) return false;
    hit.t = near > 0.0 ? near : far;
    hit.normal = near > 0.0 ?
        step(vec3(near), tMin) * -sign(direction) :
        step(tMax, vec3(far)) * -sign(direction);
    hit.position = direction * hit.t + rayOrig;
    return true;
}

void slabUv(inout hitres hit, vec3 rayOrig, vec3 size, const vec4 uvs[12], int offset) {
    vec3 t = hit.position - rayOrig;
    vec3 mask = abs(hit.normal);
    vec2 uv = mask.x * t.zy + mask.y * t.xz + mask.z * t.xy;
    vec2 dim = mask.x * size.zy + mask.y * size.xz + mask.z * size.xy;
    uv = mod(uv / (dim * 2.0) + 0.5, 1.0);

    vec4 uvmap;
    if (hit.normal.x == 1.0) uvmap = uvs[offset];
    else if (hit.normal.x == -1.0) uvmap = uvs[offset + 1];
    else if (hit.normal.y == 1.0) uvmap = uvs[offset + 2];
    else if (hit.normal.y == -1.0) uvmap = uvs[offset + 3];
    else if (hit.normal.z == 1.0) uvmap = uvs[offset + 4];
    else if (hit.normal.z == -1.0) uvmap = uvs[offset + 5];

    hit.uv = floor(mix(uvmap.xy, uvmap.zw, uv));
}

void cell(inout hitres hit, vec3 rayOrig, vec3 direction, mat3 transform, vec3 position, vec3 size, const vec4 uvs[12], int layer) {
    hitres probe = hit;
    vec3 originT = transform * rayOrig;
    vec3 directionT = transform * direction;
    if (!slabHit(probe, originT, directionT, position, size)) return;
    slabUv(probe, position, size, uvs, layer * 6);
    probe.albedo = texelFetch(Sampler0, ivec2(probe.uv), 0);
    if (probe.albedo.a < 0.1) return;

    probe.normal = probe.normal * transform;
    probe.position = direction * probe.t + rayOrig;
    hit = probe;
}

float cameoSkipColor(vec3 c) {
    float maxc = max(max(c.r, c.g), c.b);
    float minc = min(min(c.r, c.g), c.b);
    float diff = maxc - minc;
    float l = (maxc + minc) * 0.5;
    float s = (maxc - minc) / (maxc + 0.0001);
    if (s < (1.0 - min(1.0, l / 0.2))) {
        return 1.0;
    }
    if (s < 0.6 && l < 0.6 || s > 0.05 && l >= 0.6 && s < 0.55) {
        float hue = 0.0;
        if (diff > 0.0) {
            if (maxc == c.r) hue = mod((c.g - c.b) / diff, 6.0);
            else if (maxc == c.g) hue = (c.b - c.r) / diff + 2.0;
            else hue = (c.r - c.g) / diff + 4.0;
            hue /= 6.0;
        }
        if (hue < 0.1) {
            return 1.0;
        }
    }
    return 0.0;
}

vec3 cameoPickColor() {
    vec3 bandSum[CAMEO_BANDS];
    float bandHits[CAMEO_BANDS];

    for (int i = 0; i < CAMEO_BANDS; i++) {
        bandSum[i] = vec3(0);
        bandHits[i] = 0.0;
    }

    for (int y = 4; y < 24; y++) {
        for (int x = 0; x < 32; x++) {
            if (!((y < 8) || (y >= 8 && x >= 8 && x < 20))) continue;
            vec2 uv = (vec2(x, y) + 0.5) / 32.0;
            vec4 c = texture(Sampler0, uv);
            if (c.a < 0.5) continue;
            float maxc = max(max(c.r, c.g), c.b);
            float minc = min(min(c.r, c.g), c.b);
            float s = (maxc - minc) / (maxc + 0.0001);
            int br = int(min(3, floor(c.r * 4.0)));
            int bg = int(min(1, floor(c.g * 2.0)));
            int bb = int(min(3, floor(c.b * 4.0)));
            int band = ((bb * 2 + bg) * 4 + br) % CAMEO_BANDS;
            bandSum[band] += c.rgb * (c.a + (1 + s));
            bandHits[band] += c.a + (1 + s);
        }
    }

    vec3 pick = vec3(0.34, 0.18, 0.47);
    float pickScore = 0.0;

    for (int i = 0; i < CAMEO_BANDS; i++) {
        if (bandHits[i] < 1.0) continue;
        vec3 avg = bandSum[i] / bandHits[i];

        float maxc = max(max(avg.r, avg.g), avg.b);
        float minc = min(min(avg.r, avg.g), avg.b);
        float l = (maxc + minc) * 0.5;
        float s = (maxc - minc) / (maxc + 0.0001);

        float weight = bandHits[i] / 320.0;
        float lumaScore = 1.0 - abs(min(l, 0.5) - 0.5) * 2.0;
        float penalty = cameoSkipColor(avg);
        float score = s * 1.35 - penalty * 1.6 + weight * 1.05 + lumaScore * 0.12;

        if (score > pickScore) {
            pickScore = score;
            pick = avg;

            if (s > 0.0 && s < 0.72) {
                pick = (pick - minc) * (min(0.5, maxc + 0.08)) / (maxc - minc) + minc;
            }
        }
    }

    return pick;
}

hitres castRay(vec3 rayOrig, vec3 direction, float inflate) {
    const vec4 headUV[12] = vec4[](
        vec4(0, 16, 8, 8), vec4(24, 16, 16, 8), vec4(16, 0, 8, 8),
        vec4(24, 0, 16, 8), vec4(16, 16, 8, 8), vec4(24, 16, 32, 8),
        vec4(24, 16, 16, 8) + vec4(32, 0, 32, 0), vec4(0, 16, 8, 8) + vec4(32, 0, 32, 0),
        vec4(16, 0, 8, 8) + vec4(32, 0, 32, 0), vec4(24, 0, 16, 8) + vec4(32, 0, 32, 0),
        vec4(16, 16, 8, 8) + vec4(32, 0, 32, 0), vec4(24, 16, 32, 8) + vec4(32, 0, 32, 0)
    );

    const vec4 bodyUV[12] = vec4[](
        vec4(28, 32, 32, 20), vec4(20, 32, 16, 20), vec4(28, 16, 20, 20),
        vec4(36, 16, 28, 20), vec4(28, 32, 20, 20), vec4(32, 32, 40, 20),
        vec4(28, 32, 32, 20) + vec4(0, 16, 0, 16), vec4(20, 32, 16, 20) + vec4(0, 16, 0, 16),
        vec4(28, 16, 20, 20) + vec4(0, 16, 0, 16), vec4(36, 16, 28, 20) + vec4(0, 16, 0, 16),
        vec4(28, 32, 20, 20) + vec4(0, 16, 0, 16), vec4(32, 32, 40, 20) + vec4(0, 16, 0, 16)
    );

    const vec4 rightArmUV[12] = vec4[](
        vec4(40, 32, 44, 20), vec4(51, 32, 47, 20), vec4(47, 16, 44, 20),
        vec4(50, 16, 47, 20), vec4(47, 32, 44, 20), vec4(51, 32, 54, 20),
        vec4(40, 32, 44, 20) + vec4(0, 16, 0, 16), vec4(51, 32, 47, 20) + vec4(0, 16, 0, 16),
        vec4(47, 16, 44, 20) + vec4(0, 16, 0, 16), vec4(50, 16, 47, 20) + vec4(0, 16, 0, 16),
        vec4(47, 32, 44, 20) + vec4(0, 16, 0, 16), vec4(51, 32, 54, 20) + vec4(0, 16, 0, 16)
    );

    const vec4 leftArmUV[12] = vec4[](
        vec4(32, 64, 36, 52), vec4(43, 64, 39, 52), vec4(39, 48, 36, 52),
        vec4(42, 48, 39, 52), vec4(39, 64, 36, 52), vec4(43, 64, 46, 52),
        vec4(32, 64, 36, 52) + vec4(16, 0, 16, 0), vec4(43, 64, 39, 52) + vec4(16, 0, 16, 0),
        vec4(39, 48, 36, 52) + vec4(16, 0, 16, 0), vec4(42, 48, 39, 52) + vec4(16, 0, 16, 0),
        vec4(39, 64, 36, 52) + vec4(16, 0, 16, 0), vec4(43, 64, 46, 52) + vec4(16, 0, 16, 0)
    );

    const float rightArmR = radians(6.0);
    const float leftArmR = radians(-6.0);
    const mat3 rightArmT = mat3(cos(rightArmR), -sin(rightArmR), 0, sin(rightArmR), cos(rightArmR), 0, 0, 0, 1);
    const mat3 leftArmT = mat3(cos(leftArmR), -sin(leftArmR), 0, sin(leftArmR), cos(leftArmR), 0, 0, 0, 1);

    hitres hit = hitres(CAMEO_FAR, vec3(0), vec3(0), vec2(0), vec4(1));

    cell(hit, rayOrig, direction, mat3(1), vec3(0, 6, 0), vec3(4, 6, 2) + 0.25 + inflate, bodyUV, 1);
    cell(hit, rayOrig, direction, leftArmT, vec3(-6.725, 5.5, 0), vec3(1.5, 6, 2) + 0.25 + inflate, leftArmUV, 1);
    cell(hit, rayOrig, direction, rightArmT, vec3(6.725, 5.5, 0), vec3(1.5, 6, 2) + 0.25 + inflate, rightArmUV, 1);
    cell(hit, rayOrig, direction, mat3(1), vec3(0, 16, 0), vec3(4, 4, 4) + 0.5 + inflate, headUV, 1);

    cell(hit, rayOrig, direction, mat3(1), vec3(0, 6, 0), vec3(4, 6, 2) + inflate, bodyUV, 0);
    cell(hit, rayOrig, direction, leftArmT, vec3(-6.725, 5.5, 0), vec3(1.5, 6, 2) + inflate, leftArmUV, 0);
    cell(hit, rayOrig, direction, rightArmT, vec3(6.725, 5.5, 0), vec3(1.5, 6, 2) + inflate, rightArmUV, 0);
    cell(hit, rayOrig, direction, mat3(1), vec3(0, 16, 0), vec3(4, 4, 4) + inflate, headUV, 0);

    return hit;
}

vec4 cameoRender(vec2 uv, float aspectRatio, vec3 color) {
  vec3 start = color * 0.5;
  vec3 end = color * 0.25;
  vec3 result = mix(start, end, uv.y);

  // 배경 그라데이션에만 세피아 틴트 (머리는 아래에서 불투명하게 덮여 영향 없음)
  result = cameoSoftMixEase(result, mix(vec3(0.20, 0.18, 0.14), vec3(0.97, 0.90, 0.74), sqrt(1.0 - uv.y)), 0.7);

  vec3 direction = normalize(vec3(-1));
  vec3 side = normalize(cross(vec3(0, 1, 0), direction));
  vec3 up = cross(direction, side);

  vec2 uv1 = uv * 2.0 - 1.0;
  vec3 rayOrig = vec3(20.0, 35.0, 20.0);

  rayOrig += 10.0 * (side * uv1.x * aspectRatio - up * uv1.y);

  hitres hit = castRay(rayOrig, direction, 0.0);

  if (hit.t >= CAMEO_FAR) {
    hit = castRay(rayOrig, direction, 0.25);
    if (hit.t < CAMEO_FAR) {
      result = mix(result, vec3(0), hit.albedo.a);
    }
  } else {
    vec3 lightDir = normalize(vec3(0.0, 2.0, 1.0));
    vec3 lighting = cameoShade(hit.normal, lightDir);

    vec4 c = hit.albedo;
    c.rgb *= lighting;

    result = mix(result, c.rgb, c.a);
  }

  result = cameoSoftMixEase(result, mix(vec3(0.20, 0.18, 0.14), vec3(0.97, 0.90, 0.74), sqrt(1.0 - uv.y)), 0.12);

  return vec4(result, 1.0);
}
