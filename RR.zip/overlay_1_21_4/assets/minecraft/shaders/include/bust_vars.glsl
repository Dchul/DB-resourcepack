#version 150

#define BUST_SIZE 14

#define BUST_OUTLINE_COLOR     (255, 255, 255)
#define BUST_OUTLINE_OPACITY   100

#define BUST_SHADOW_HUE           0
#define BUST_SHADOW_SAT_ADJ     -12
#define BUST_SHADOW_LIGHT_ADJ   -36
#define BUST_SHADOW_OPACITY     100

#define BUST_OVERLAY_COLOR     (224, 201, 137)
#define BUST_OVERLAY_OPACITY   8

#define BUST_BASE_HUE           0
#define BUST_BASE_SAT_ADJ      -2
#define BUST_BASE_LIGHT_ADJ   -12
#define BUST_BASE_OPACITY     100
