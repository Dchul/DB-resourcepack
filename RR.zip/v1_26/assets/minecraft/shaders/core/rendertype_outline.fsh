#version 330

// PabloGlow: 팀색 커스텀 이펙트 — 프리미엄 5종 + 살아있는 단색 10종 (바닐라 26.x 원본의 완전 상위집합)
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

vec3 pablo_hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

bool pablo_eq(vec3 a, vec3 b) {
    return all(lessThan(abs(a - b), vec3(0.01)));
}

// 살아있는 단색: 기준 HSV에 미세 hue 흔들림(±0.012) + 밝기 숨쉬기(±5%). ph=색별 위상
vec3 pablo_solid(float h, float s, float v, float t, float ph) {
    float hh = fract(h + 0.012 * sin(t * 1.1 + ph) + 1.0);
    float vv = v * (0.95 + 0.05 * sin(t * 1.7 + ph * 1.3));
    return pablo_hsv2rgb(vec3(hh, s, vv));
}

// 팀색 리매핑: 프리미엄 이펙트 5종 + 살아있는 단색 10종. &f 흰색은 통과.
vec3 pablo_effect(vec3 c) {
    float t = GameTime * 1200.0;
    if (max(c.r, max(c.g, c.b)) < 0.004) {                 // &0 -> 프리즘 (풀스펙트럼 14s)
        return pablo_hsv2rgb(vec3(fract(GameTime * 85.0), 1.0, 1.0));
    }
    if (pablo_eq(c, vec3(0.6667, 0.6667, 0.6667))) {       // &7 -> 오로라 (파스텔 일렁임+물결)
        float h = mix(0.50, 0.92, 0.5 + 0.5 * sin(t * 0.28));
        float v = 0.85 + 0.15 * sin(t * 0.9);
        return pablo_hsv2rgb(vec3(h, 0.50, v));
    }
    if (pablo_eq(c, vec3(0.0, 0.0, 0.6667))) {             // &1 -> 갤럭시
        float h = mix(0.61, 0.78, 0.5 + 0.5 * sin(t * 0.5));
        float v = 0.85 + 0.15 * sin(t * 3.7);
        return pablo_hsv2rgb(vec3(h, 0.80, v));
    }
    if (pablo_eq(c, vec3(0.0, 0.6667, 0.0))) {             // &2 -> 에메랄드 펄스
        float v = 0.775 + 0.225 * sin(t * 1.6);
        return pablo_hsv2rgb(vec3(0.42, 0.75, v));
    }
    if (pablo_eq(c, vec3(0.0, 0.6667, 0.6667))) {          // &3 -> 오션 웨이브
        float h = mix(0.46, 0.54, 0.5 + 0.5 * sin(t * 0.8));
        return pablo_hsv2rgb(vec3(h, 0.85, 1.0));
    }
    // 살아있는 단색 (Open Color 기준 HSV + 미세 애니메이션)
    if (pablo_eq(c, vec3(1.0, 0.3333, 0.3333)))    return pablo_solid(0.000, 0.58, 1.000, t, 0.0); // &c 빨강 #ff6b6b
    if (pablo_eq(c, vec3(0.6667, 0.0, 0.0))) {             // &4 적색 발광 -> 크림슨 펄스 (에메랄드 스타일, 후원 보상)
        float v = 0.775 + 0.225 * sin(t * 1.4);
        return pablo_hsv2rgb(vec3(0.0, 0.80, v));
    }
    if (pablo_eq(c, vec3(1.0, 0.6667, 0.0))) {             // &6 골드 -> 골드 펄스 (에메랄드 스타일)
        float v = 0.775 + 0.225 * sin(t * 1.8);
        return pablo_hsv2rgb(vec3(0.116, 0.98, v));
    }
    if (pablo_eq(c, vec3(1.0, 1.0, 0.3333)))       return pablo_solid(0.133, 0.60, 1.000, t, 2.1); // &e 노랑 #ffe066
    if (pablo_eq(c, vec3(0.3333, 1.0, 0.3333)))    return pablo_solid(0.361, 0.61, 0.812, t, 2.8); // &a 초록 #51cf66
    if (pablo_eq(c, vec3(0.3333, 0.3333, 1.0)))    return pablo_solid(0.576, 0.79, 0.941, t, 3.5); // &9 파랑 #339af0
    if (pablo_eq(c, vec3(0.3333, 1.0, 1.0)))       return pablo_solid(0.519, 0.56, 0.910, t, 4.2); // &b 하늘 #66d9e8
    if (pablo_eq(c, vec3(1.0, 0.3333, 1.0)))       return pablo_solid(0.942, 0.58, 0.941, t, 4.9); // &d 분홍 #f06595
    if (pablo_eq(c, vec3(0.6667, 0.0, 0.6667)))    return pablo_solid(0.800, 0.60, 0.910, t, 5.6); // &5 보라 #cc5de8
    if (pablo_eq(c, vec3(0.3333, 0.3333, 0.3333))) return pablo_solid(0.583, 0.11, 0.588, t, 6.3); // &8 진회색 #868e96
    return c;                                                                                       // &f 흰색 통과
}

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }
    fragColor = vec4(ColorModulator.rgb * pablo_effect(vertexColor.rgb), ColorModulator.a);
}
